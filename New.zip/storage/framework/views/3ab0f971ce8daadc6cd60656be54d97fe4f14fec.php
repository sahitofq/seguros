<?php $__env->startComponent('layout.header'); ?>
<?php if (isset($__componentOriginal4c4b4c4a5ddaa72db9b0b2bb328380369541f451)): ?>
<?php $component = $__componentOriginal4c4b4c4a5ddaa72db9b0b2bb328380369541f451; ?>
<?php unset($__componentOriginal4c4b4c4a5ddaa72db9b0b2bb328380369541f451); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<div id="loader">
    <div class="spinner">
        <div class="rect1"></div>
        <div class="rect2"></div>
        <div class="rect3"></div>
        <div class="rect4"></div>
        <div class="rect5"></div>
    </div>
</div>
<div id="dialog" class="hide" title="Error">
    <p>Error en la conexion con las aseguradoras</p>
</div>
<div id="content">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php $__env->startComponent('layout.footer'); ?>
<?php if (isset($__componentOriginalf6bd1d2915694ecca3345f79e2b4f36b8b5f0150)): ?>
<?php $component = $__componentOriginalf6bd1d2915694ecca3345f79e2b4f36b8b5f0150; ?>
<?php unset($__componentOriginalf6bd1d2915694ecca3345f79e2b4f36b8b5f0150); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\wamp64\www\puma\New\resources\views/layout/site-layout.blade.php ENDPATH**/ ?>