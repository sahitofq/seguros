
<?php $__env->startSection('mailinfo'); ?>
    <tr>
        <td width="73"></td>
        <td width="577">
            <p style="font-weight: bold; font-size: 18px;">Cordial saludo <br>
                <?php echo e($users->form_person_name); ?></p>
        </td>
    </tr>
    <tr>
        <td height="99">&nbsp;</td>
        <td>Recibimos tu solicitud para adquirir un seguro confiable con<br>
            nosotros, tenemos para ti la mejor cotización que arroja <br>
            nuestro sistema, la cual puedes descargar ahora.</td>
    </tr>
    <tr>
        <td height="75" colspan="2" style="text-align: center">
            <a href="<?php echo e(env('APP_URL')); ?>/excel/<?php echo e($users->seguro_nombre); ?>/<?php echo e($users->form_id); ?>">
                <img src="<?php echo e(env('APP_URL')); ?>/img/email/boton.jpg" width="345" height="44" />
            </a>
        </td>
    </tr>
    <tr>
        <td height="76">&nbsp;</td>
        <td>En poco nos contactaremos contigo para para conocer un poco<br>
            más sobre lo que estás buscando, o si prefieres escríbenos a: </td>
    </tr>
    <tr>
        <td height="62">&nbsp;</td>
        <td><a href="mailto:<?php echo e($asesor->asesor_correo); ?>" style="color: #c66700"><?php echo e($asesor->asesor_correo); ?></a><br>
            o comunícate al <span style="color: #c66700">+ 57 <?php echo e($asesor->asesor_telefono); ?></span></td>
    </tr>
    <tr>
        <td height="46">&nbsp;</td>
        <td>¡Feliz día!</td>
    </tr>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.mail_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\puma\New\resources\views/mail/usuario_venta.blade.php ENDPATH**/ ?>