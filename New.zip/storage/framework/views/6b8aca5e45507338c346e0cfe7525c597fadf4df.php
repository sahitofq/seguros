<?php $__env->startSection('content'); ?>

    <div class="inf-stuck">
        <div class="linea">
            <div class="container">
                <h1 class="record wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
                    COTIZA TU SEGURO TODO RIESGO EN TIEMPO RECORD
                </h1>
            </div>
        </div>
    </div>
    <div class="container">
        <article class="row">

            <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
                <div class="box_content">
                    <div class="banner_box">
                        <div class="campo-inf" style="margin-top: 30px">
                            <div class="wrapper">
                                <div class="box-info-detalle">
                                    <div class="box-info-segmento">
                                        <div class="segmento-colum col-lg-4 col-md-4 col-sm-12">
                                            <img src="<?php echo e(asset('img/seguros/' . strtolower($seguro->seguro_seguro) . '.jpg')); ?>"
                                                alt="<?php echo e($seguro->seguro_seguro); ?>" />
                                        </div>
                                        <div class="segmento-colum col-lg-4 col-md-4 col-sm-12 espaciotop">
                                            <div class="segmento-colum col-lg-6 col-md-6 col-sm-6">
                                                <div class="til-respues">Tipo de seguro</div>
                                                <div class="til-respues-price">Todo riesgo</div>
                                            </div>
                                            <div class="segmento-colum col-lg-6 col-md-6 col-sm-6">
                                                <div class="til-respues">Daño - Pérdida total</div>
                                                <div class="til-respues-price"> <?php echo e($seguro->seguro_d_total); ?>%</div>
                                            </div>
                                            <div class="segmento-colum col-lg-6 col-md-6 col-sm-6">
                                                <div class="til-respues">Hurto - Pérdida total</div>
                                                <div class="til-respues-price"> <?php echo e($seguro->seguro_h_total); ?>%</div>
                                            </div>
                                            <div class="segmento-colum col-lg-6 col-md-6 col-sm-6">
                                                <div class="til-respues">Daños a terceros</div>
                                                <div class="til-respues-price">
                                                    $<?php echo e(number_format($seguro->seguro_tercero, 0, ',', '.')); ?>

                                                    millones</div>
                                            </div>
                                            <div class="segmento-colum col-lg-6 col-md-6 col-sm-6">
                                                <div class="til-respues">Daño - Pérdida parcial deducible</div>
                                                <div class="til-respues-price">
                                                    <?php echo e(!strpos($seguro->seguro_d_parcial, 'SMMLV') ? '$' . number_format($seguro->seguro_d_parcial, 0, ',', '.') : $seguro->seguro_d_parcial . '%'); ?>

                                                </div>
                                            </div>
                                            <div class="segmento-colum col-lg-6 col-md-6 col-sm-6">
                                                <div class="til-respues">Hurto - Pérdida parcial deducible</div>
                                                <div class="til-respues-price">
                                                    <?php echo e(!strpos($seguro->seguro_h_parcial, 'SMMLV') ? '$' . number_format($seguro->seguro_h_parcial, 0, ',', '.') : $seguro->seguro_h_parcial . '%'); ?>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="segmento-colum col-lg-4 col-md-4 col-sm-12">
                                            <div class="price-tarjeta">
                                                <div class="fondo-tarjeta">
                                                    <div class="text-tarjetap tilg"> Pago de contado <b class="u-fontBold">
                                                            $<?php echo e(number_format($seguro->seguro_real_seguro, 0, ',', '.')); ?>

                                                        </b> </div>
                                                    <!--  <div class="text-tarjeta campo-fon">
                                                                                                                                        <div class="text-tarjeta-prin col-lg-6 col-md-12 col-sm-12">
                                                                                                                                            Subtotal:
                                                                                                                                        </div>
                                                                                                                                        <div class="text-tarjeta-gen">
                                                                                                                                            $1.898.378
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div class="text-tarjeta">
                                                                                                                                        <div class="text-tarjeta-prin col-lg-6 col-md-12 col-sm-12">
                                                                                                                                            Gastos de emisión:
                                                                                                                                        </div>
                                                                                                                                        <div class="text-tarjeta-gen">
                                                                                                                                            $1.898.378
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div class="text-tarjeta campo-fon">
                                                                                                                                        <div class="text-tarjeta-prin col-lg-6 col-md-12 col-sm-12">
                                                                                                                                            Valor IVA:
                                                                                                                                        </div>
                                                                                                                                        <div class="text-tarjeta-gen">
                                                                                                                                            $1.898.378
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div class="text-tarjeta">
                                                                                                                                        <div class="text-tarjeta-prin col-lg-6 col-md-12 col-sm-12">
                                                                                                                                            Subtotal:
                                                                                                                                        </div>
                                                                                                                                        <div class="text-tarjeta-gen">
                                                                                                                                            $1.898.378
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                -->
                                                    <div class="btns central">
                                                        <form action="<?php echo e(route('excel')); ?>" method="post" target="_blank">
                                                            <?php echo e(csrf_field()); ?>

                                                            <input type="hidden" value="<?php echo e($seguro->seguro_nombre); ?>"
                                                                name="seguro">
                                                            <button class="btn_ver" type="submit">¡Iniciar
                                                                Compra!</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if(count($resumen)): ?>
                                        <div class="box-info-respt">
                                            <div class="general-text">
                                                <div class="general-text-black">Resumen</div>
                                                <ul>
                                                    <?php $__currentLoopData = $resumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($item->resumen_nombre); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(count($afectacion)): ?>
                                        <div class="box-info-respt">
                                            <div class="general-text">
                                                <div class="general-text-black">Afectación a terceros</div>
                                                <ul>
                                                    <?php $__currentLoopData = $afectacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($item->resumen_nombre); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(count($perdida)): ?>
                                        <div class="box-info-respt">
                                            <div class="general-text">
                                                <div class="general-text-black">Daños o pérdidas</div>
                                                <ul>
                                                    <?php $__currentLoopData = $perdida; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($item->resumen_nombre); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(count($conducir)): ?>
                                        <div class="box-info-respt">
                                            <div class="general-text">
                                                <div class="general-text-black">Si no puedes conducir</div>
                                                <ul>
                                                    <?php $__currentLoopData = $conducir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($item->resumen_nombre); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(count($lastimas)): ?>
                                        <div class="box-info-respt">
                                            <div class="general-text">
                                                <div class="general-text-black">Si te lastimas</div>
                                                <ul>
                                                    <?php $__currentLoopData = $lastimas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($item->resumen_nombre); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(count($otros)): ?>
                                        <div class="box-info-respt">
                                            <div class="general-text">
                                                <div class="general-text-black">Otros beneficios</div>
                                                <ul>
                                                    <?php $__currentLoopData = $otros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($item->resumen_nombre); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </article>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\puma\New\resources\views/todo-riesgo-detalle.blade.php ENDPATH**/ ?>