
<?php $__env->startSection('mailinfo'); ?>
    <tr>
        <td colspan="2"><img src="<?php echo e(env('APP_URL')); ?>img/email/cabezote.jpg" width="650" height="129" alt="" /></td>
    </tr>
    <tr>
        <td width="73"></td>
        <td width="577">
            <p style="font-weight: bold; font-size: 18px;">Cordial saludo <br>
                <?php echo e($users->form_person_name); ?></p>
        </td>
    </tr>
    <tr>
        <td height="99">&nbsp;</td>
        <td>Recibimos tu solicitud para adquirir un seguro confiable con <br>
            nosotros, la cual nos arrojó información que tu vehículo, <br>
            no puede obtener una cotización en este momento.</td>
    </tr>
    <tr>
        <td height="95">&nbsp;</td>
        <td>Si prefieres puedes escríbenos a: <a href="mailto:<?php echo e($asesor->asesor_correo); ?>"
                style="color: #c66700"><?php echo e($asesor->asesor_correo); ?></a> o comunícate al <span style="color: #c66700"><br>
                + 57 <?php echo e($asesor->asesor_telefono); ?></span>, o en poco nos contactaremos contigo <br>
            para para conocer un poco más sobre lo que estás buscando.</td>
    </tr>
    <tr>
        <td height="46">&nbsp;</td>
        <td>¡Feliz día!</td>
    </tr>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.mail_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\puma\New\resources\views/mail/usuario_error.blade.php ENDPATH**/ ?>