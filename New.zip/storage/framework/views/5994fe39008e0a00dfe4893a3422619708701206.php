
<?php $__env->startSection('mailinfo'); ?>
    <tr>
        <td width="73"></td>
        <td width="577">
            <p style="font-weight: bold; font-size: 18px;">Hola asesor puma, el usuario: </p>
        </td>
    </tr>
    <tr>
        <td height="99" rowspan="2">&nbsp;</td>
        <td style="text-align: left">
            <table width="541" border="0" cellspacing="0" cellpadding="0">
                <tbody>
                    <tr>
                        <td style="text-align: left"><strong>Nombre</strong>: <?php echo e($users->form_person_name); ?> </td>
                        <td style="text-align: left"><strong><?php echo e($users->form_person_doctype); ?>

                            </strong><?php echo e($users->form_person_docnumber); ?> </td>
                    </tr>
                    <tr>
                        <td style="text-align: left"><strong>Cel: </strong><?php echo e($users->form_person_phone); ?> </td>
                        <td style="text-align: left"><strong>mail:</strong><?php echo e($users->form_person_email); ?></td>
                    </tr>
                </tbody>
            </table>
            <br>
        </td>
    </tr>
    <tr>
        <td>Solicito una cotización de su seguro todo riesgo, si deseas descarga el PDF de
            cotización, ya puedes contactarlo.</td>
    </tr>
    <tr>
        <td height="75" colspan="2" style="text-align: center">
            <a href="<?php echo e(env('APP_URL')); ?>/excel/<?php echo e($users->seguro_nombre); ?>/<?php echo e($users->form_id); ?>">
                <img src="<?php echo e(env('APP_URL')); ?>/img/email/boton.jpg" width="345" height="44" />
            </a>
        </td>
    </tr>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.mail_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp64\www\puma\New\resources\views/mail/asesor_venta.blade.php ENDPATH**/ ?>